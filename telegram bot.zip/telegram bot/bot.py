
import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart
import os

# Load config from config.py (create from config.example.py)
try:
    import config
except Exception as e:
    print("Please copy config.example.py -> config.py and set BOT_TOKEN and ADMINS.")
    raise

BOT_TOKEN = config.BOT_TOKEN
ADMINS = config.ADMINS if hasattr(config, "ADMINS") else []

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Simple in-memory DB (replace with real DB)
USERS = {}  # user_id -> {"role": "user"/"pro"/"worker"/"admin"}

def is_admin(user_id):
    return user_id in ADMINS

def is_free_user(user_id):
    role = USERS.get(user_id, {}).get("role","user")
    return role in ["pro","worker","admin"]

# Keyboards
def user_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add("📄 Referat yaratish", "📊 Slayd yaratish")
    kb.add("🌐 Tilmoch AI", "💳 To'lovlar")
    return kb

def admin_button():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add("🛠 ADMIN PANEL")
    return kb

def admin_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row("👤 Foydalanuvchilar", "📊 Statistika")
    kb.row("⭐ PRO qo'shish", "🧑‍💼 Ishchi qo'shish")
    kb.row("❌ Ban", "📨 Xabar yuborish")
    kb.row("🔙 Orqaga")
    return kb

@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    uid = message.from_user.id
    if is_admin(uid):
        await message.answer("Assalomu alaykum, admin!", reply_markup=admin_button())
    else:
        USERS.setdefault(uid, {"role":"user"})
        await message.answer("Assalomu alaykum! Botga xush kelibsiz.", reply_markup=user_menu())

# Admin panel opener
@dp.message(lambda m: m.text == "🛠 ADMIN PANEL")
async def open_admin(message: types.Message):
    uid = message.from_user.id
    if not is_admin(uid):
        return await message.answer("⛔ Siz admin emassiz!")
    await message.answer("🛠 Admin panel:", reply_markup=admin_menu())

# Simple handlers for demo
@dp.message(lambda m: m.text == "📄 Referat yaratish")
async def make_referat(message: types.Message):
    await message.answer("Referat generator - tayyor. (stub)\nIltimos, mavzuni yuboring.")

@dp.message(lambda m: m.text == "📊 Slayd yaratish")
async def make_slides(message: types.Message):
    await message.answer("Slayd generator - tayyor. (stub)\nIltimos, mavzu va shablonni tanlang.")

@dp.message(lambda m: m.text == "🌐 Tilmoch AI")
async def tilmoch_menu(message: types.Message):
    await message.answer("Tilmoch AI - matnni maxsus imloga aylantirish (stub).\nMatn yuboring.")

@dp.message(lambda m: m.text == "💳 To'lovlar")
async def payments_menu(message: types.Message):
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton(text="Click (demo)", callback_data="pay_click"))
    await message.answer("To'lov usullari:", reply_markup=kb)

@dp.callback_query(lambda c: c.data == "pay_click")
async def pay_click_cb(query: types.CallbackQuery):
    await query.message.answer("Click to'lov (stub) - bu joyda real API qo'shiladi.")

# Admin functions (stubs)
@dp.message(lambda m: m.text == "⭐ PRO qo'shish")
async def cmd_add_pro(message: types.Message):
    await message.answer("ADMIN: PRO qilish uchun user ID yuboring. (stub)")

@dp.message(lambda m: m.text == "🧑‍💼 Ishchi qo'shish")
async def cmd_add_worker(message: types.Message):
    await message.answer("ADMIN: Ishchi qilish uchun user ID yuboring. (stub)")

# Minimal safety: block unknown commands
@dp.message()
async def echo_all(message: types.Message):
    await message.answer("Bot tayyor. Iltimos menyu orqali tanlang.")

async def main():
    print("Starting bot... (make sure you created config.py from config.example.py)")
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print("Error:", e)
