
# services/docx_gen.py
# Minimal DOCX generator using python-docx
from docx import Document
from docx.shared import Pt
import os

DEFAULT_FONT = "Times New Roman"
DEFAULT_SIZE = 14

def create_referat_docx(title, author, subject, content_paragraphs, out_path="referat.docx"):
    doc = Document()
    # Title
    p = doc.add_paragraph()
    run = p.add_run(title + "\n")
    run.font.name = DEFAULT_FONT
    run.font.size = Pt(DEFAULT_SIZE)
    # Meta
    doc.add_paragraph(f"Muallif: {author}")
    doc.add_paragraph(f"Fan: {subject}")
    doc.add_paragraph("")
    # Content
    for para in content_paragraphs:
        p = doc.add_paragraph()
        run = p.add_run(para)
        run.font.name = DEFAULT_FONT
        run.font.size = Pt(DEFAULT_SIZE)
    doc.save(out_path)
    return out_path
