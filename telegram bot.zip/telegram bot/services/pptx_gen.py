
# services/pptx_gen.py
# Minimal PPTX generator using python-pptx
from pptx import Presentation
from pptx.util import Pt

DEFAULT_FONT = "Times New Roman"
DEFAULT_SIZE = 14

def create_slides(title, slides_contents, template_path=None, out_path="presentation.pptx"):
    prs = Presentation()
    for idx, txt in enumerate(slides_contents):
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        tf = slide.shapes.title
        tf.text = title if idx==0 else ""
        body = slide.shapes.placeholders[1].text_frame
        p = body.paragraphs[0]
        p.text = txt
        for paragraph in body.paragraphs:
            for run in paragraph.runs:
                run.font.name = DEFAULT_FONT
                run.font.size = Pt(DEFAULT_SIZE)
    prs.save(out_path)
    return out_path
