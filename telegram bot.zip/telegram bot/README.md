
Telegram Bot Project (skeleton)
--------------------------------
This project is a complete skeleton for the Slide/Referat/Transliterator bot you requested.
IMPORTANT: This archive DOES NOT contain any real tokens or admin IDs.

Files:
- bot.py                : main bot code (aiogram) using polling or webhook (switchable)
- config.example.py     : configuration example - put your BOT_TOKEN and ADMINS in config.py
- requirements.txt      : Python dependencies
- utils/transliterate.py: transliteration (tilmoch) module (UZ->Qaraqalpaq rules)
- services/docx_gen.py  : DOCX (referat) generator stub (Times New Roman 14)
- services/pptx_gen.py  : PPTX (slide) generator stub (Times New Roman 14)
- services/payment_stub.py: Payment integration stubs (Click) - no credentials
- templates/            : placeholder pngs for slide templates (empty files)
- README.md             : this file
- LICENSE               : MIT
- example_env           : example environment variables to set (do NOT commit secrets)

Quickstart:
1) Copy config.example.py -> config.py and fill in your BOT_TOKEN and ADMINS list.
2) Create a Python virtualenv and install requirements: pip install -r requirements.txt
3) Run bot: python bot.py
4) Deploy to your hosting (Render/Cyclic/Deta) and set env vars accordingly.

Notes:
- All "heavy" AI or payment calls are stubbed and documented; replace stubs with real API calls.
- DOCX/PPTX modules already set Times New Roman 14 pt for main text.
- This project is ready to extend; see comments in files.
