
# transliterate.py
# Basic transliteration / tilmoch rules (Uzbek ASCII-ish -> Qaraqalpaq accented)
# This is a small rule-based converter you can expand.

MAPPING = {
    "o'": "ó", "g'": "ǵ", "sh": "sh", "ch": "ch",
    "a'": "á", "ng": "ń", "i'": "í"
}

def to_qaraqalpaq(text: str) -> str:
    # naive replacements, for demo purposes
    t = text
    for k in sorted(MAPPING.keys(), key=lambda x: -len(x)):
        t = t.replace(k, MAPPING[k])
    return t
