
# Copy this file to config.py and fill the values.
# IMPORTANT: Do NOT commit real tokens to public repos.

BOT_TOKEN = ""  # e.g. "123456:ABC-DEF..."
ADMINS = []     # e.g. [123456789, 987654321]

# Payment / Click placeholders (fill in when ready)
CLICK_MERCHANT_ID = ""
CLICK_SECRET = ""
CLICK_SERVICE_ID = ""

# AI / External services placeholders
OPENAI_API_KEY = ""
YANDEX_TRANSLATE_KEY = ""

# APP SETTINGS
LANGUAGES = ["uz","qq","ru"]  # uz = Uzbek, qq = Qaraqalpaq, ru = Russian
DEFAULT_FONT = "Times New Roman"
DEFAULT_FONT_SIZE = 14
